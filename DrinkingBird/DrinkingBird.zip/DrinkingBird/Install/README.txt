1) Set the exe to run as admin
2) If setting up a shortcut to the drinkingbird.exe, ensure to set the shortcut to run as administrator to prevent security warnings.
3) The screen lock is set to drip the status when locked